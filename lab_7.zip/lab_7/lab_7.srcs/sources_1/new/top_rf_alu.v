`timescale 1ns / 1ps

module top_rf_alu #(
    parameter TICK_CYCLES = 50_000_000
)(
    input wire clk,
    input wire rst,
    output wire [15:0] physical_leds
);
    localparam IDLE       = 4'd0;
    localparam WRITE_X1   = 4'd1;
    localparam WRITE_X2   = 4'd2;
    localparam ADD_STATE  = 4'd3;
    localparam SUB_STATE  = 4'd4;
    localparam AND_STATE  = 4'd5;
    localparam OR_STATE   = 4'd6;
    localparam XOR_STATE  = 4'd7;
    localparam SLL_STATE  = 4'd8;
    localparam SRL_STATE  = 4'd9;
    localparam BEQ_STATE  = 4'd10;

    reg [3:0] state;
    reg [3:0] next_state;

    
    reg [31:0] count;
    wire tick = (count == TICK_CYCLES - 1);

    always @(posedge clk) begin
        if (rst || tick) count <= 32'd0;
        else             count <= count + 1;
    end

    reg WriteEnable;
    reg [4:0] rs1;
    reg [4:0] rs2;
    reg [4:0] rd;
    reg [31:0] WriteData;
    reg [3:0] ALUControl;
    reg [31:0] expected;

    wire [31:0] ReadData1;
    wire [31:0] ReadData2;
    wire [31:0] ALUResult;
    wire Zero;

    reg_file rf (
        .clk(clk),
        .rst(rst),
        .WriteEnable(WriteEnable),
        .rs1(rs1),
        .rs2(rs2),
        .rd(rd),
        .WriteData(WriteData),
        .ReadData1(ReadData1),
        .ReadData2(ReadData2)
    );

    ALU alu (
        .A(ReadData1),
        .B(ReadData2),
        .ALUControl(ALUControl),
        .ALUResult(ALUResult),
        .Zero(Zero)
    );

    always @(posedge clk) begin
        if (rst)       state <= IDLE;
        else if (tick) state <= next_state;
    end

   
    always @(*) begin
        case (state)
            IDLE:      next_state = WRITE_X1;
            WRITE_X1:  next_state = WRITE_X2;
            WRITE_X2:  next_state = ADD_STATE;
            ADD_STATE: next_state = SUB_STATE;
            SUB_STATE: next_state = AND_STATE;
            AND_STATE: next_state = OR_STATE;
            OR_STATE:  next_state = XOR_STATE;
            XOR_STATE: next_state = SLL_STATE;
            SLL_STATE: next_state = SRL_STATE;
            SRL_STATE: next_state = BEQ_STATE;
            BEQ_STATE: next_state = ADD_STATE;   
            default:   next_state = IDLE;
        endcase
    end

 
    always @(*) begin
        WriteEnable = 1'b0;
        rs1         = 5'd0;
        rs2         = 5'd0;
        rd          = 5'd0;
        WriteData   = 32'd0;
        ALUControl  = 4'b0000;
        expected    = 32'd0;

        case (state)
            WRITE_X1: begin
                WriteEnable = 1'b1;
                rd          = 5'd1;
                WriteData   = 32'h10101010;
            end
            WRITE_X2: begin
                WriteEnable = 1'b1;
                rd          = 5'd2;
                WriteData   = 32'h01010101;
            end
            ADD_STATE: begin
                rs1 = 5'd1; rs2 = 5'd2; ALUControl = 4'b0000;
                expected = 32'h11111111;
            end
            SUB_STATE: begin
                rs1 = 5'd1; rs2 = 5'd2; ALUControl = 4'b0001;
                expected = 32'h0F0F0F0F;
            end
            AND_STATE: begin
                rs1 = 5'd1; rs2 = 5'd2; ALUControl = 4'b0010;
                expected = 32'h00000000;
            end
            OR_STATE: begin
                rs1 = 5'd1; rs2 = 5'd2; ALUControl = 4'b0011;
                expected = 32'h11111111;
            end
            XOR_STATE: begin
                rs1 = 5'd1; rs2 = 5'd2; ALUControl = 4'b0100;
                expected = 32'h11111111;
            end
            SLL_STATE: begin
                rs1 = 5'd1; rs2 = 5'd2; ALUControl = 4'b0101;
                expected = 32'h20202020;
            end
            SRL_STATE: begin
                rs1 = 5'd1; rs2 = 5'd2; ALUControl = 4'b0110;
                expected = 32'h08080808;
            end
            BEQ_STATE: begin
                rs1 = 5'd1; rs2 = 5'd1; ALUControl = 4'b0001;
                expected = 32'h00000000;
            end
            default: ;
        endcase
    end

    wire in_alu_state = (state >= ADD_STATE) && (state <= BEQ_STATE);
    wire ok = in_alu_state && (ALUResult == expected) &&
              ((state != BEQ_STATE) || Zero);

    assign physical_leds[15:8] = ALUResult[7:0];
    assign physical_leds[7]    = Zero;
    assign physical_leds[6]    = ok;
    assign physical_leds[5:4]  = 2'b00;
    assign physical_leds[3:0]  = state;

endmodule