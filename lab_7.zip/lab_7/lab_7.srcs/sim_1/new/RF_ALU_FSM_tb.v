`timescale 1ns / 1ps

module RF_ALU_FSM_tb;

    reg clk = 0;
    reg rst = 1;
    wire [15:0] physical_leds;

    top_rf_alu #(.TICK_CYCLES(4)) dut (
        .clk(clk),
        .rst(rst),
        .physical_leds(physical_leds)
    );

    always #5 clk = ~clk;

    always @(posedge clk) begin
        if (!rst && dut.tick && dut.state >= 3) begin
            if (dut.ok)
                $display("%0d ns: state %0d PASSED, result = %h", $time, dut.state, dut.ALUResult);
            else
                $display("%0d ns: state %0d FAILED, result = %h", $time, dut.state, dut.ALUResult);
        end
    end

    initial begin
        #22;
        rst = 0;
        #1000;      
        $finish;
    end

endmodule